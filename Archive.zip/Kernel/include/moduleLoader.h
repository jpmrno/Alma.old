#ifndef _MODULE_LOADER_H_
#define _MODULE_LOADER_H_

#include <define.h>

void loadModules(void * payloadStart, void ** moduleTargetAddress);

#endif